
<template>
  <HeaderBar />
  <router-view />
</template>

<script setup>
import HeaderBar from './components/HeaderBar.vue'
</script>
